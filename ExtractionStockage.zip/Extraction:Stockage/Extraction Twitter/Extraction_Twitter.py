#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: salma_loudari
"""

#tweet_reply_to id = none vraie tweet
#tweet_reply_to id =  vraie tweet

import matplotlib.dates as mdates
import pylab as plb
import pandas as pd
from TwitterSearch import *
from dateutil import parser #Permet d'utiliser le format date
from textblob import Blobber #Permet de réaliser l'analyse des sentiments
from textblob_fr import PatternTagger, PatternAnalyzer
from sqlalchemy import create_engine
import psycopg2 as pg
import io
#load python script that batch loads pandas df to sql
from io import StringIO



Id_user= []
Screename_user = []
Name_user = []
User_description = []
User_followers_count=[]
User_friends_count =[]
User_favourites_count=[]
User_statuses_count=[]
User_geo_enabled =[]
Tweet_geo= []
Tweet_coordinates= []
Tweet_place= []
Tweet_contributors= []
Verified_account =[]
Account_date_creation=[]
User_location=[]
Tweet_id =[]
Tweet_URL = []
Tweet_text =[]
Tweet_date_creation =[]
Tweet_retweet_count =[]
Tweet_hashtags =[]
Tweet_mentions =[]
Tweet_reply_to_user_name=[]
Tweet_reply_to_user_id=[]
Tweet_reply_to_tweet_id=[]
Retweet_status =[]
Tweet_lang =[]

consumer_key = ['dLipeeKq54VbChk24CsV1Sogr', '3v9gKs9KWwfHxAuMmBgIE8jaw', 'qpUp0xtdfiBPBtBMxzbNXMd8h',
                'XpuwAn9OMBcWGeQNvoPZ69QIu', 'NYARbeG6y79N5k7MNt6ueK3L1', 'Qd6ry4NvpAcM2TBprtmNv41Uj',
                'QfXiBks8G6pMHIFDUxeeDLW37', 'C9uM0HndBaYgTx4QuYoSxEpBs', 'PvHynNYscVpbni5s7L6Qdm7MP',
                'A8514W8sACwLukrQqerFz9NFS', '8nXro72VhLCIsXzuR2c2eD0qI', 'RX49BZSjraUq1ER4wcWS6QfsM',
                'yXVeLxbbX1F4z1dAXHxBmKpHO', 'XyWfu0fRqOnR60IxmOASUrjRt', 'TkqwpPUQVeDlob4H5soCiBM6q',
                'O5a4hrLxVjNMfYo6CqQZ8GGs7']

consumer_secret = ['l5t23Z1QuXQdGbDcF3JwHgvCqRXVPwyg8ZLQZfbpA8kzYhPpiD', 'sHOTBWvv2msq7Ojat79ECCcdg993PTtV4FJwO2DEepcZhPnqLd',
                   'MGr17cEcy5MZt0UWVOMctg9UFe6hhLAcZPK4ZNCQdc8cAqLCXp', '2915An4yPLcQ2rI6dYjSPZQq9IyYIFmYmDQXKEPg0YQ2xUwRlF',
                   'ySjmDMpoMqqcvHCoOf8lIHBwFzFSN5aUY6DuxkZZ3LPM97XIYf', 'bbiTkBHjjqNQ9xKYFnzcRJVZf0OP7RhbB6y8o4cv8F5pYPlCUA',
                   '8eXtr8U3tdZVzVYu0pGk09EqxBJqARjhF3jzWBRTdDRXJL1pqV', 'uTnQnaDR9lX9CrGL5NivGYsJZOqhoOPnroikSGmL3KYY9o9fNj',
                   'OFVkHTPmjqO7K9ooAl2lwuR4B7jaLrOxTliPnlVjRbK4lXD0Rn', 'kFjECikiOX4Kw5tlDI5bgeGDqkI8PVZBDwNIknZdEBQXWNz4ss',
                   'NPT6fPHtCATaLRxGSe6CC84cHLieu1vaLugkhLCiO9CRFWOWfN', 'jKtG3VMkyputedMMWAgzto1fDZdriI2xyX7avovelE0xhLRZSg',
                   '9fjnHgrUKTh6yjB6s5O70qfUzJzWqdjpQ6gmgiBKPjSEVMadFb', 'xWUEZTElLhNryWfzMLrhyLuYwyaX4L0jW0yAAy604pt5QI2vrh',
                   'nXK2xKwfHlEzc7GefL0Tw2HKvrNdvfdzQ4XGggBWmvXcLBbX5e', 'BQzT4Nfe5b5UQdD9y4Yq8pmhxfc1N2ESYCGd8spfCyRu6PZCv0']


access_token = ['985176661015564289-tW7ca9hNQdBQfKbY8182sfnxDLgkpV5', '985176661015564289-uZAeJvWYDFuowQo2PftCjMIJHm5DYgg',
                '985176661015564289-NzRbxdnSvk1NxU392e7vwURMi5VtRNQ', '985176661015564289-VehFff3LyO0jUJXBoeMXgknp09ge94g',
                '1000840621240832002-BTwBi414BXTLAaiEemEajeWynipqxe', '1000840621240832002-W2oFx6ihA3BFjR1r6jKyoGYESmwrZx',
                '1000840621240832002-2WPsUjIScBUyNNGSVmU8Kt93pYqwwu', '1000850880319680512-7O9OSpNlzsToypIq6nbWMJFeSz55Iw',
                '1000850880319680512-x0gepGkEmKLXKPSahVwnhEsoJxO6EC', '1000850880319680512-prRUxIAXuvQKWM2zjGRABGg7bfELRb',
                '1000854526423916545-xs9MjAPN7ecs3qSkTuSM3Su1W6kHvp', '1000854526423916545-DbZKiTo0gWQk3J0eV2KAP7rZF3zKlJ',
                '1000854526423916545-duwhBolHH4TYipZUxpvLhcTK3fPDwR', '1000856850286424064-awyMsTqGtyv0kRnaOivcDJOK2sQXes',
                '1000856850286424064-Zoj6rkG6jSn2EYl9ZdiaMyRqx7u6Ns', '1000856850286424064-ECJAuDRAD54merE3Ku4rzZW72YAUqu']



access_secret = ['0wGEamiq6EmrrNlcpuDEK4PBwlFOB3Vt66sqexrulI0jE', 'DdnCINS9MhEmV5J2ZcX4AfCKBd1idC6gWl9J6KsmZBMHv',
                 'C9yfqGPjbTufvWWbotqI1qqwhErwvZxDeEZMpcv6kAvw6', 'zGeMVx2l6xYfklkzku18jnedxd6XOihrb1n8POaCtVi8T',
                 'j8vuwt7UfoK2jbnWX7H6Fmp5WbsT4fcBdJh3CZglC3mKk', 'Z4HT8SAL2q77go4wWrWNjk96YgmZdLAi4YdDWQXPjsEjB',
                 'nyiUG3hCcjdfNQa76DCQbgNPp2xRJtSaHEJ7KcgE5rYRS', 'humqyauSyOydQypMvmvm4jMu69DrjCkauA4y1lkQk9d4u',
                 'dL4J3k67BM0NforKzTRi3Pr7nI77hkhovBTnyvm94yXZM', 'Mf0isIS5jh2hipuL7IVMXsZbhW9wDF9YYWdqDJZAPa7fR',
                 'faVLq3vCPBcxKLxjVHZb4iGrDWrTE0T37pLTqXywrgtSG', 'pJyqfukOv4M3m2zp3621REIR4uQK30llBAI50Dm3KqDhg',
                 'vl6lCMH7U3Z8TjI8QruS7eJbj4MVsIXi20ef9hvlNwZHf', '5sI1EvoGv5JoHxhe467hjtasNmL8Fq3zYytyyQJPexqts',
                 'k5dteD5mylYwHV9G49KM8iSTOQxjNWFVSqkfuPP3U11Ky', 'iBHClmTOFrrtUusQQZIWhD6LM2F2ZD4AE6o2eUWFVC1QP']

def collect_tweets():
    import pandas 
    try:
        tso = TwitterSearchOrder()  # On crée un objet TwitterSearchOrder
        tso.set_keywords(['renault'])  # On met les mots clés de notre recherche de tweets
        
        kf = 0
        
        ts = TwitterSearch(
        consumer_key=consumer_key[kf],
        consumer_secret=consumer_secret[kf],
        access_token=access_token[kf],
        access_token_secret=access_secret[kf])

        compteur = 0
        if compteur < 5: 
            for tweet in ts.search_tweets_iterable(tso): 
        

                Id_user.append(tweet['user']['id_str'])
                Screename_user.append(tweet['user']['screen_name'])
                Name_user.append(tweet['user']['name'])
                User_description.append(tweet['user']['description'].replace( "\\" , " " ).replace( "\t" , " " ).replace( "\n" , " " ).replace( "\r" , " " ))
                User_followers_count.append(tweet['user']['followers_count'])
                User_friends_count.append(tweet['user']['friends_count'])
                User_favourites_count.append(tweet['user']['favourites_count'])
                User_statuses_count.append(tweet['user']['statuses_count']) 
                User_geo_enabled.append(tweet['user']['geo_enabled'])
                Tweet_geo.append(tweet['geo'])
                Tweet_coordinates.append(tweet['coordinates'])
                Tweet_place.append(tweet['place'])
                Tweet_contributors.append( tweet['contributors'])
                Verified_account.append(tweet['user']['verified'])
                Account_date_creation.append(parser.parse(tweet['user']['created_at']))
                User_location.append(tweet['user']['location'])
                Tweet_id.append(tweet['id_str'])
                url = ''
                if (len ([x['expanded_url'] for x in tweet['entities']['urls']]) > 0):
                          url = tweet['entities']['urls'][0]['expanded_url']
                Tweet_URL.append(url)
                Tweet_text.append(tweet['text'].replace( "\\" , " " ).replace( "\t" , " " ).replace( "\n" , " " ).replace( "\r" , " " ))
                Tweet_date_creation.append(parser.parse( tweet['created_at'].split("+")[0]))
                
                Tweet_retweet_count.append(tweet['retweet_count'])
                
            
                
                Tweet_hashtags.append(";".join( [x['text'] for x in tweet['entities']['hashtags']]))
                Tweet_mentions.append(";".join([x['screen_name'] for x in tweet['entities']['user_mentions']]))
                Tweet_reply_to_user_name.append(tweet['in_reply_to_screen_name'])
                Tweet_reply_to_user_id.append(tweet['in_reply_to_user_id'])
                Tweet_reply_to_tweet_id.append(tweet['in_reply_to_status_id'])
                Retweet_status.append(tweet['retweeted'])
                Tweet_lang.append(tweet['lang'])
            compteur += 1
   
  
    except ConnectionResetError:
            print('erreur de connexion, on change kf')
            kf = (kf+1) % 16
    except ConnectionError:
            print('erreur de connexion, on change kf')
            kf = (kf + 1) % 16
    except tweepy.TweepError:
            print('erreur de connexion, on change kf')
            kf = (kf + 1) % 16
    except TwitterSearchException as e:
        print(e)
    df =pandas.DataFrame({ 'Id_user' : Id_user , 'Screename_user' :Screename_user , 'Name_user': Name_user , 'User_description' : User_description , 'Verified_account' : Verified_account , 'User_followers_count' : User_followers_count , 'User_friends_count' : User_friends_count, 'User_favourites_count' : User_favourites_count, 'User_statuses_count' : User_statuses_count , 'Account_date_creation' : Account_date_creation, 'User_geo_enabled' : User_geo_enabled, 'User_location' :User_location, 'Tweet_geo' :Tweet_geo, 'Tweet_coordinates' : Tweet_coordinates , 'Tweet_place' : Tweet_place , 'Tweet_contributors' : Tweet_contributors , 'Tweet_id' : Tweet_id , 'Tweet_URL' : Tweet_URL , 'Tweet_text' : Tweet_text , 'Tweet_date_creation' : Tweet_date_creation , 'Tweet_retweet_count' : Tweet_retweet_count , 'Tweet_hashtags' : Tweet_hashtags , 'Tweet_mentions' :Tweet_mentions , 'Tweet_reply_to_user_name' : Tweet_reply_to_user_name , 'Tweet_reply_to_user_id' : Tweet_reply_to_user_id , 'Tweet_reply_to_tweet_id' : Tweet_reply_to_tweet_id ,'Retweet_status' : Retweet_status, 'Tweet_lang' : Tweet_lang}, 
                     columns =['Id_user', 'Screename_user', 'Name_user', 'User_description', 'Verified_account', 'User_followers_count', 'User_friends_count', 'User_favourites_count',
                             'User_statuses_count', 'Account_date_creation', 'User_geo_enabled', 'User_location', 'Tweet_geo', 'Tweet_coordinates', 'Tweet_place', 'Tweet_contributors', 
                             'Tweet_id', 'Tweet_URL', 'Tweet_text', 'Tweet_date_creation', 'Tweet_retweet_count', 'Tweet_hashtags', 'Tweet_mentions', 'Tweet_reply_to_user_name',
                            'Tweet_reply_to_user_id', 'Tweet_reply_to_tweet_id', 'Retweet_status', 'Tweet_lang'])
    return (df)
#print(df.values)
#print(df.columns.values)
#print(Verified_account)
#print(Tweet_date_creation) 

        
def create_table():  
    address = 'postgresql://master:rL5*,JNx=f?]T[aG@tnp-db1.cvgzhtxd3wud.eu-west-1.rds.amazonaws.com:5432/postgres'
    engine = create_engine(address)
    connection = engine.raw_connection()
    cursor = connection.cursor()
    print("connexion OK")
    #create the table but first drop if it already exists
    command = '''DROP TABLE IF EXISTS Twitter_salma;
        CREATE TABLE Twitter_salma (Id_user varchar(5000) , Screename_user varchar (5000), Name_user varchar (5000), User_description varchar (5000), Verified_account bool ,
                                    User_followers_count varchar (5000), User_friends_count varchar (5000), User_favourites_count varchar (5000),
                                    User_statuses_count varchar (5000), Account_date_creation timestamp, User_geo_enabled varchar (5000), User_location varchar (5000), Tweet_geo varchar (5000), 
                                    Tweet_coordinates varchar (5000), Tweet_place varchar (5000), Tweet_contributors varchar (5000), 
                                    Tweet_id varchar (5000), Tweet_URL varchar (5000), Tweet_text varchar (5000), Tweet_date_creation timestamp, Tweet_retweet_count varchar (5000), 
                                    Tweet_hashtags varchar (5000), Tweet_mentions varchar (5000), Tweet_reply_to_user_name varchar (5000),
                                    Tweet_reply_to_user_id varchar (5000), Tweet_reply_to_tweet_id varchar (5000), Retweet_status varchar (5000), Tweet_lang varchar (5000) );'''
    
                                
    #boucle sur le remplissage juste, la création se fait une seule fois
    cursor.execute(command)
    connection.commit()
    return("table created")
    #stream the data using 'to_csv' and StringIO(); then use sql's 'copy_from' function
    
    
def enrich_table(df):
    address = 'postgresql://master:rL5*,JNx=f?]T[aG@tnp-db1.cvgzhtxd3wud.eu-west-1.rds.amazonaws.com:5432/postgres'
    engine = create_engine(address)
    connection = engine.raw_connection()
    cursor = connection.cursor()
    output = StringIO()
#ignore the index
    df.to_csv(output, sep='\t', header=False, index= False)
#jump to start of stream
    output.seek(0)
    contents = output.getvalue()
    cur = connection.cursor()
#null values become ''
    cur.copy_from(output, 'Twitter_salma', null='')   
    connection.commit()
    command = ''' grant select on all tables in schema public to master;'''
    cursor.execute(command)
    connection.commit()
#    result_set = cur.execute("SELECT * FROM Twitter_salma where (Tweet_lang = 'fr') " )  
    cur.close()
    return("table enriched")

def show_table():
    import pandas as pd
    address = 'postgresql://master:rL5*,JNx=f?]T[aG@tnp-db1.cvgzhtxd3wud.eu-west-1.rds.amazonaws.com:5432/postgres'
    engine = create_engine(address)
    connection = engine.raw_connection()
    sql = "SELECT * FROM Twitter_salma"
    df = pd.read_sql(sql, connection)
    return(df)
    
def main_first():
    
    df = collect_tweets()
    enrich_table(df)
    return(show_table())

def main():
    
    df = collect_tweets()
    enrich_table(df)
    return(show_table())
import time    

#for k in range (999999999):
#    print(main())
#    time.sleep(15*60)

print(main())