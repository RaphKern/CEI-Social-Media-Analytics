#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 20:39:35 2019

@author: salma_loudari
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb 10 09:57:15 2019

@author: salma_loudari
"""
# ligne : 
#windows store = ubuntu ligne de commande 
#commentaires voir groupe AirFrance comment treats 
# id video en input => colonnes : videoID / commentID / nbre de like / date etc
#Lien entre les 2 table avec left join sur la clé videoID

#faire un dossier avec des fichiers .py
#dash : regarder air france orga 



import googleapiclient
from googleapiclient.discovery import build 
from googleapiclient.errors import HttpError 
from oauth2client.tools import argparser
import pandas as pd 
import matplotlib as plt
from dateutil import parser 

from textblob import Blobber #Permet de réaliser l'analyse des sentiments
from textblob_fr import PatternTagger, PatternAnalyzer
from sqlalchemy import create_engine
import psycopg2 as pg

from io import StringIO

# Consumer and Access keys of youtube API
def collect_youtube():
    DEVELOPER_KEY = "AIzaSyDK6UF0oRCqhjGZXEkLZ9Yzgn-5XJsJXsU"
    YOUTUBE_API_SERVICE_NAME = "youtube"
    YOUTUBE_API_VERSION = "v3"
    
    ## Create a connection to the youtube api, using build function
    youtube = build( YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION, developerKey = DEVELOPER_KEY)
    
    
    
    
    
    search_response = youtube.search().list(q= "suzuki" #Search term, empty in this case as we have channel ID
                                            , type= "video", #Required media, either video/channel/etc. 
                                            part="snippet", #Which part of result to be retrieved 
                                            maxResults = "50", #Max reults of 50 possile
                                           
                                            order="viewCount" #In the order in which you want the results to be retrieved 
                                           ).execute()
   
    search_videos = []
    for search_result in search_response.get("items", []):
        search_videos.append(search_result["id"]["videoId"])
        video_ids = ",".join(search_videos)
   
    video_response = youtube.videos().list(
            id=video_ids,
            part='id, snippet, statistics').execute()  
  
   
    
    video_id, channel_id, title, date, description , viewCount, likeCount , dislikeCount, favoriteCount, commentCount = [], [], [], [], [], [], [], [], [] , []
    
    
#    
#    LHR = 'UCSeWBJOEs5ICRDy5Iw_mdFg' #The channel ID of the required Clients, obtained from the result of youtube.search command
#    BA = 'UCSs-N1quBfssFcYyqm6V_oA'
#    AF= "UCt6_7e1yAZxhn5E2ojiZA6w"
    
    
    for item in video_response['items']:
        
        title.append(item['snippet']['title'].replace( "\\" , " " ).replace( "\t" , " " ).replace( "\n" , " " ).replace( "\r" , " " ))
        video_id.append(item['id'])
        date.append(parser.parse(item['snippet']['publishedAt']))
        description.append(item['snippet']['description'].replace( "\\" , " " ).replace( "\t" , " " ).replace( "\n" , " " ).replace( "\r" , " " ))
        channel_id.append(item['snippet']['channelId'])
        
        try:
            viewCount.append(item['statistics']['viewCount'])
        except KeyError:
            viewCount.append(None)
            
        try:
            likeCount.append(item['statistics']['likeCount'])
        except KeyError:
            likeCount.append(None)
            
        try:
            dislikeCount.append(item['statistics']['dislikeCount'])
        except KeyError:
            dislikeCount.append(None)
            
        try:
            favoriteCount.append(item['statistics']['favoriteCount'])
        except KeyError:
            favoriteCount.append(None)
            
        try:
            commentCount.append(item['statistics']['commentCount'])
        except KeyError:
            commentCount.append(None)
    
        
    print (video_id, channel_id, title, date, description , viewCount, likeCount , dislikeCount, favoriteCount, commentCount)
    print (len(video_id), len(channel_id), len(title), len(date), len(description) , len(likeCount) , len(dislikeCount), len(favoriteCount), len(commentCount))
    # To save the data into a pandas dataframe
    df = pd.DataFrame(data=[[channel_id[i], video_id[i],title[i], date[i], description[i] , viewCount[i], likeCount[i] , dislikeCount[i], favoriteCount[i], commentCount[i]] for i in range(len(title))],columns=['Channel_id', 'Video_id', 'Title', 'UploadDate', 'Description',
                           'viewCount', 'likeCount' , 'dislikeCount', 'favoriteCount', 'commentCount'])
    return(df)
    


    
def create_table():  
    address = 'postgresql://master:rL5*,JNx=f?]T[aG@tnp-db1.cvgzhtxd3wud.eu-west-1.rds.amazonaws.com:5432/postgres'
    engine = create_engine(address)
    connection = engine.raw_connection()
    cursor = connection.cursor()
    print("connexion OK")
    #create the table but first drop if it already exists
    command = '''DROP TABLE IF EXISTS Youtube_Suzuki;
        CREATE TABLE Youtube_Suzuki (Channel_id varchar(500) , Video_id varchar (500), Title varchar (500), Date timestamp, Description varchar(5000) ,
        viewCount varchar (500) , likeCount varchar (500) , dislikeCount varchar (500), favoriteCount varchar (500), commentCount varchar (500));'''
    
                                
    #boucle sur le remplissage juste, la création se fait une seule fois
    cursor.execute(command)
    connection.commit()
    return("table created")
    #stream the data using 'to_csv' and StringIO(); then use sql's 'copy_from' function

    
def enrich_table(df):
    address = 'postgresql://master:rL5*,JNx=f?]T[aG@tnp-db1.cvgzhtxd3wud.eu-west-1.rds.amazonaws.com:5432/postgres'
    engine = create_engine(address)
    connection = engine.raw_connection()
    cursor = connection.cursor()
    output = StringIO()
#ignore the index
    df.to_csv(output, sep='\t', header=False, index= False)
#jump to start of stream
    output.seek(0)
    contents = output.getvalue()
    cur = connection.cursor()
#null values become ''
    cur.copy_from(output, 'Youtube_Suzuki', null='')   
    connection.commit()
    command = ''' grant select on all tables in schema public to master;'''
    cursor.execute(command)
    connection.commit()
#    result_set = cur.execute("SELECT * FROM Twitter_Suzuki where (Tweet_lang = 'fr') " )  
    cur.close()
    return("table enriched")
    

    
def show_table():
    import pandas as pd
    address = 'postgresql://master:rL5*,JNx=f?]T[aG@tnp-db1.cvgzhtxd3wud.eu-west-1.rds.amazonaws.com:5432/postgres'
    engine = create_engine(address)
    connection = engine.raw_connection()
    sql = "SELECT * FROM Youtube_Suzuki"
    df = pd.read_sql(sql, connection)
    return(df)
 
 
def main():
    df = collect_youtube()
    enrich_table(df)
    return(show_table())

import time

for k in range (2):
    
    print(main())
    time.sleep(30)


