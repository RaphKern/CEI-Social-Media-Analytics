#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb 10 09:13:37 2019

@author: salma_loudari
"""

import googleapiclient
from googleapiclient.discovery import build 
from googleapiclient.errors import HttpError 
from oauth2client.tools import argparser
import pandas as pd 
import matplotlib as plt

DEVELOPER_KEY = "AIzaSyDK6UF0oRCqhjGZXEkLZ9Yzgn-5XJsJXsU"  #Your developper keys
YOUTUBE_API_SERVICE_NAME = "youtube"  #Name of the google serive
YOUTUBE_API_VERSION = "v3" #Version of API used


 
youtube = build( YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION,  developerKey=DEVELOPER_KEY ) #The YouTube client to retrive data



search_response = youtube.search().list(
 q= "renault" , ## Your search term stored in options below
 type= "channel", ## Type of media
 part="id,snippet", ## Search about parts you want to extract
 maxResults="10"## Your max-results stored in options below
).execute()


LHR = 'UCSeWBJOEs5ICRDy5Iw_mdFg' #The channel ID of the required Clients, obtained from the result of youtube.search command
BA = 'UCSs-N1quBfssFcYyqm6V_oA'
AF= "UCt6_7e1yAZxhn5E2ojiZA6w"




search_videos = []

# Merge video ids obtained from search to be used 
for search_result in search_response.get('items', []):
    search_videos.append(search_result['id']['videoId']) 
    
video_ids = ','.join(search_videos)


count=0
dataObtained={}
names=[]

for i in range(len(search_videos)):
    try:
        t={}
        results = youtube.commentThreads().list(
            part="snippet",
            videoId=search_videos[i],maxResults='100',
            textFormat="plainText"
          ).execute()
        
        
        print ("This is video number" , i+1)
        print (len(results["items"]))
        for item in results["items"]:
            comment = item["snippet"]["topLevelComment"]
            author = comment["snippet"]["authorDisplayName"]
            text = comment["snippet"]["textDisplay"]
            print ("Author: ", author, "\nText :", text, "\n\n")
#            temp[k] = text
            count+=1
#            dataObtained.update(t)
#            data_youtube[k].append(d)        
    except:
        print ("Comments disabled")



