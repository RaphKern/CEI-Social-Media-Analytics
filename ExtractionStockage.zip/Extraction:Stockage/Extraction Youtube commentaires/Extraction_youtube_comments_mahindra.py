#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 13 08:16:43 2019

@author: salma_loudari
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar  8 00:23:35 2019

@author: salma_loudari
"""
# R py script en R x

import googleapiclient
from googleapiclient.discovery import build 
from googleapiclient.errors import HttpError 
from oauth2client.tools import argparser
import pandas as pd 
import matplotlib as plt
from dateutil import parser 

from textblob import Blobber #Permet de réaliser l'analyse des sentiments
from textblob_fr import PatternTagger, PatternAnalyzer
from sqlalchemy import create_engine
import psycopg2 as pg

from io import StringIO

def collect_youtube_comments():
    DEVELOPER_KEY = "AIzaSyDK6UF0oRCqhjGZXEkLZ9Yzgn-5XJsJXsU"
    YOUTUBE_API_SERVICE_NAME = "youtube"
    YOUTUBE_API_VERSION = "v3"
    
    ## Create a connection to the youtube api, using build function
    youtube = build( YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION, developerKey = DEVELOPER_KEY)
    
    
    
    
    
    search_response = youtube.search().list(q= "mahindra" #Search term, empty in this case as we have channel ID
                                            , type= "video", #Required media, either video/channel/etc. 
                                            part="snippet", #Which part of result to be retrieved 
                                            maxResults = "50", #Max reults of 50 possile
                                           
                                            order="viewCount" #In the order in which you want the results to be retrieved 
                                           ).execute()
    search_videos = []
    for search_result in search_response.get("items", []):
        search_videos.append(search_result["id"]["videoId"])
   

    comment_id, comment_text , video_id, author, date_publication, likeCount = [],[],[],[],[],[]
    for i in range(len(search_videos)):
        try:
        
            results = youtube.commentThreads().list(
                    part="snippet",
                    videoId=search_videos[i],maxResults='100',
                    textFormat="plainText"
                    ).execute()

            for item in results["items"]:
                comment_id.append(item["snippet"]["topLevelComment"]["id"])
                video_id.append(item["snippet"]["topLevelComment"]["snippet"]["videoId"])
                author.append(item["snippet"]["topLevelComment"]["snippet"]["authorDisplayName"])
                comment_text.append(item["snippet"]["topLevelComment"]["snippet"]["textDisplay"].replace( "\t" , " " ).replace( "\n" , " " ).replace( "\r" , " " ).replace( "  " , " " ))
                date_publication.append( item["snippet"]["topLevelComment"]["snippet"]["publishedAt"])
                likeCount.append(item["snippet"]["topLevelComment"]["snippet"]["likeCount"])
         
            
        except:
                comment_id.append("")
                video_id.append("")
                author.append("")
                comment_text.append("")
                date_publication.append( "")
                likeCount.append("")
                
    df_comments = pd.DataFrame(data=[[comment_id[i], video_id[i],author[i], comment_text[i], date_publication[i] , likeCount[i] ] for i in range(len(comment_id))],
                                    columns=['comment_id', 'video_id', 'author', 'comment_text', 'date_publication', 'likeCount' ])
    return(df_comments)

def create_table_comments():  
    address = 'postgresql://master:rL5*,JNx=f?]T[aG@tnp-db1.cvgzhtxd3wud.eu-west-1.rds.amazonaws.com:5432/postgres'
    engine = create_engine(address)
    connection = engine.raw_connection()
    cursor = connection.cursor()
    print("connexion OK")
    #create the table but first drop if it already exists
    command = '''DROP TABLE IF EXISTS Youtube_comments_Mahindra;
        CREATE TABLE Youtube_comments_Mahindra (comment_id varchar(500) , video_id varchar (500), author varchar (500), comment_text varchar(5000) ,
        date_publication timestamp , likeCount varchar (500) );'''
    
                                
    #boucle sur le remplissage juste, la création se fait une seule fois
    cursor.execute(command)
    connection.commit()
    return("table comments created")
    #stream the data using 'to_csv' and StringIO(); then use sql's 'copy_from' function   
    
def enrich_table_comments(df):
    address = 'postgresql://master:rL5*,JNx=f?]T[aG@tnp-db1.cvgzhtxd3wud.eu-west-1.rds.amazonaws.com:5432/postgres'
    engine = create_engine(address)
    connection = engine.raw_connection()
    cursor = connection.cursor()
    output = StringIO()
#ignore the index
    df.to_csv(output, sep='\t', header=False, index= False)
#jump to start of stream
    output.seek(0)
    contents = output.getvalue()
    cur = connection.cursor()
#null values become ''
    cur.copy_from(output, 'Youtube_comments_Mahindra', null='')   
    connection.commit()
    command = ''' grant select on all tables in schema public to master;'''
    cursor.execute(command)
    connection.commit()
#    result_set = cur.execute("SELECT * FROM Twitter_Mahindra where (Tweet_lang = 'fr') " )  
    cur.close()
    return("table comments enriched")
   
def show_table_comments():
    import pandas as pd
    address = 'postgresql://master:rL5*,JNx=f?]T[aG@tnp-db1.cvgzhtxd3wud.eu-west-1.rds.amazonaws.com:5432/postgres'
    engine = create_engine(address)
    connection = engine.raw_connection()
    sql = "SELECT * FROM Youtube_comments_Mahindra"
    df = pd.read_sql(sql, connection)
    return(df)

def main_comments():
    df = collect_youtube_comments()
    enrich_table_comments(df)
    return(show_table_comments())

print(main_comments())